#' Recovery diagnostic for a calibrated endpoint
#'
#' Injects direction-aligned shared effects into the replayed arm of a
#' sample-level fit and reports how often the resulting selected correlation
#' exceeds its own replay reference. This describes the detection boundary of
#' the endpoint; it is a diagnostic on top of the fitted reference and is not a
#' second core method. A non-significant replay result does not by itself say
#' which alternatives the endpoint can resolve, and this diagnostic answers
#' that question for the tested grid.
#'
#' @param fit A \code{selcorr} object fitted with \code{method = "replay"}.
#' @param type Only \code{"recovery"} is defined in version 0.1.
#' @param fractions Fractions of the eligible pool receiving injected effects.
#' @param effect_sizes Injected effect sizes in units of one member gene's
#'   expression SD.
#' @param n_outer Outer replicates per grid cell (a fresh gene draw each time).
#' @param n_perm Reference draws per outer replicate.
#' @param seed Integer seed.
#' @param checkpoint Optional checkpoint path (per grid cell).
#' @param parallel Use \pkg{future.apply} across outer replicates.
#' @param alpha Rejection level.
#' @param verbose Print progress.
#' @return A data frame with columns \code{fraction}, \code{effect_size},
#'   \code{rejection_rate}, \code{mc_se}, \code{median_observed_r},
#'   \code{median_null_mean} and \code{median_p}.
#' @export
diagnose <- function(fit, type = "recovery",
                     fractions = c(0.05, 0.10, 0.25, 0.50),
                     effect_sizes = c(0.2, 0.4, 0.6, 1.0),
                     n_outer = 30L, n_perm = 100L, seed = 20260913L,
                     checkpoint = NULL, parallel = FALSE, alpha = 0.05,
                     verbose = TRUE) {
  if (!inherits(fit, "selcorr")) stop("`fit` must be a selcorr object.", call. = FALSE)
  if (!identical(type, "recovery")) stop("Only type = \"recovery\" is defined in selcorr 0.1.", call. = FALSE)
  if (is.null(fit$data$replayed_prepared)) {
    stop("diagnose(type = \"recovery\") requires a sample-level fit.", call. = FALSE)
  }
  prep <- fit$data$replayed_prepared
  anchored <- fit$data$anchored_tbl
  spec <- fit$spec$selection

  sign_vec <- stats::setNames(sign(anchored$effect), anchored$gene)
  observed_pool <- apply_selection(spec, pair_arms(anchored, prep$fit_fun(prep$expr)))$pool_genes
  if (length(observed_pool) < 10L) stop("Eligible pool too small for a recovery diagnostic.", call. = FALSE)

  design_n <- matrix(1, nrow = prep$n_samples, ncol = 1L)
  fit_n <- limma::lmFit(prep$expr, design_n)
  fitted <- fit_n$coefficients %*% t(design_n)
  residuals <- prep$expr - fitted
  groups <- levels(prep$group)
  case_idx <- prep$group == groups[length(groups)]
  ctrl_idx <- !case_idx

  rows <- list()
  for (delta in effect_sizes) {
    for (fr in fractions) {
      n_spike <- max(1L, round(fr * length(observed_pool)))
      obs_r <- numeric(n_outer); pvals <- numeric(n_outer); nulls <- numeric(0)
      for (j in seq_len(n_outer)) {
        set.seed(seed + j + round(delta * 1000))
        genes_j <- sample(observed_pool, n_spike, replace = FALSE)
        spiked <- prep$expr
        g <- intersect(genes_j, rownames(spiked))
        s <- sign_vec[g]
        spiked[g, case_idx] <- spiked[g, case_idx, drop = FALSE] + delta / 2 * s
        spiked[g, ctrl_idx] <- spiked[g, ctrl_idx, drop = FALSE] - delta / 2 * s
        obs <- apply_selection(spec, pair_arms(anchored, prep$fit_fun(spiked)))
        obs_r[j] <- obs$r
        f_n <- limma::lmFit(spiked, design_n)
        ft <- f_n$coefficients %*% t(design_n)
        rs <- spiked - ft
        set.seed(seed + 100000L + j + round(delta * 1000))
        perms <- replicate(n_perm, sample.int(ncol(spiked)), simplify = FALSE)
        rr <- vapply(perms, function(pm) {
          apply_selection(spec, pair_arms(anchored, prep$fit_fun(ft + rs[, pm, drop = FALSE])))$r
        }, numeric(1))
        rr <- rr[is.finite(rr)]
        nulls <- c(nulls, rr)
        pvals[j] <- (1 + sum(rr >= obs$r)) / (1 + length(rr))
      }
      rej <- mean(pvals < alpha, na.rm = TRUE)
      rows[[length(rows) + 1L]] <- data.frame(
        fraction = fr, effect_size = delta, rejection_rate = rej,
        mc_se = sqrt(rej * (1 - rej) / n_outer),
        median_observed_r = stats::median(obs_r, na.rm = TRUE),
        median_null_mean = mean(nulls, na.rm = TRUE),
        median_p = stats::median(pvals, na.rm = TRUE),
        stringsAsFactors = FALSE)
      if (verbose) {
        message(sprintf("  recovery: delta = %.2f, fraction = %.2f, rejection = %.2f",
                        delta, fr, rej))
      }
      if (!is.null(checkpoint)) {
        saveRDS(do.call(rbind, rows), checkpoint)
      }
    }
  }
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}
