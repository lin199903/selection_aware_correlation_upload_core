make_toy <- function(n = 200L, seed = 1L) {
  set.seed(seed)
  genes <- sprintf("G%03d", seq_len(n))
  list(
    x = data.frame(gene = genes, effect = rnorm(n), fdr = runif(n, 0, 0.3),
                   stringsAsFactors = FALSE),
    y = data.frame(gene = genes, effect = rnorm(n), fdr = runif(n, 0, 0.3),
                   stringsAsFactors = FALSE)
  )
}

test_that("identical seeds give identical reference draws and summaries", {
  toy <- make_toy()
  f1 <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                method = "gene_label", B = 25, seed = 99, verbose = FALSE)
  f2 <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                method = "gene_label", B = 25, seed = 99, verbose = FALSE)
  expect_identical(f1$replay_statistics, f2$replay_statistics)
  expect_equal(f1$p_value, f2$p_value)
  expect_equal(f1$null_mean, f2$null_mean)
})

test_that("different seeds give different draw sequences", {
  toy <- make_toy()
  f1 <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                method = "gene_label", B = 25, seed = 1, verbose = FALSE)
  f2 <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                method = "gene_label", B = 25, seed = 2, verbose = FALSE)
  expect_false(identical(f1$replay_statistics$r, f2$replay_statistics$r))
})

test_that("parallel execution consumes the same draws as serial execution", {
  skip_if_not(requireNamespace("future.apply", quietly = TRUE), "future.apply not installed")
  skip_if_not(requireNamespace("future", quietly = TRUE), "future not installed")
  toy <- make_toy(n = 150L)
  serial <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                    method = "gene_label", B = 20, seed = 5, verbose = FALSE)
  par <- selcorr(toy$x, toy$y, selection = selection_spec("de_anchor"),
                 method = "gene_label", B = 20, seed = 5, parallel = TRUE, verbose = FALSE)
  ## Draw sequences are generated before evaluation, so both runs must agree.
  expect_identical(serial$replay_statistics$r, par$replay_statistics$r)
  expect_equal(serial$p_value, par$p_value)
})

test_that("sample-level reference draws are reproducible across runs", {
  set.seed(3)
  genes <- sprintf("G%03d", 1:120)
  group <- factor(c(rep("case", 6), rep("control", 6)), levels = c("control", "case"))
  expr <- matrix(rnorm(120 * 12), nrow = 120, dimnames = list(genes, NULL))
  x <- data.frame(gene = genes, effect = rnorm(120),
                  fdr = c(runif(30, 0, 0.01), runif(90, 0, 0.6)))
  f1 <- selcorr(x, list(expr = expr, group = group), selection = selection_spec("de_anchor"),
                method = "replay", B = 10, seed = 4, verbose = FALSE)
  f2 <- selcorr(x, list(expr = expr, group = group), selection = selection_spec("de_anchor"),
                method = "replay", B = 10, seed = 4, verbose = FALSE)
  expect_identical(f1$replay_statistics$r, f2$replay_statistics$r)
})
