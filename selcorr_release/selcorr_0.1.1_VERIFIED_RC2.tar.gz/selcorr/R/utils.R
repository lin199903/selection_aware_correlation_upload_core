## Internal constants and helpers. These reproduce the frozen production
## conventions and must not be changed silently: the defaults below are the
## thresholds used by the archived analyses.

.y_chromosome_genes <- c(
  "UTY", "USP9Y", "DDX3Y", "KDM5D", "EIF1AY", "ZFY", "SRY",
  "NLGN4Y", "RPS4Y1", "RPS4Y2", "TSPY1", "RBMY1A1", "DAZ1",
  "PRKY", "AMELY", "TBL1Y", "PCDH11Y", "TMSB4Y", "VCY",
  "CDY1", "CDY2A", "HSFY1", "TXLNGY", "BPY2", "PRY"
)

.selcorr_defaults <- list(
  fdr_cut = 0.05,
  abs_effect_cut = 0.3,
  min_selected = 4L,
  tail = "upper",
  add_one = TRUE
)

#' Safe Pearson correlation for a selected set
#'
#' Returns \code{NA} when the selected set is too small or degenerate, matching
#' the archived analyses. A missing correlation is a legitimate outcome (the
#' endpoint is undefined for that draw), not an error.
#'
#' @param x Numeric vector of effects from the first arm.
#' @param y Numeric vector of effects from the second arm.
#' @param min_selected Minimum number of genes required.
#' @return A numeric scalar, possibly \code{NA}.
#' @keywords internal
safe_cor <- function(x, y, min_selected = .selcorr_defaults$min_selected) {
  if (length(x) < min_selected || length(y) != length(x)) return(NA_real_)
  if (stats::sd(x) == 0 || stats::sd(y) == 0) return(NA_real_)
  suppressWarnings(as.numeric(stats::cor(x, y, method = "pearson")))
}

#' Add-one upper-tail p value
#'
#' The estimator used by the archived analyses. It is reported for the
#' observed statistic relative to a reference distribution.
#'
#' @param observed Numeric scalar.
#' @param reference Numeric vector of valid reference draws.
#' @return A list with \code{p}, \code{n_upper}, \code{n_valid} and the Monte
#'   Carlo standard error.
#' @keywords internal
add_one_upper_p <- function(observed, reference) {
  ref <- reference[is.finite(reference)]
  n_valid <- length(ref)
  if (n_valid == 0L || !is.finite(observed)) {
    return(list(p = NA_real_, n_upper = NA_integer_, n_valid = n_valid, mcse = NA_real_))
  }
  n_upper <- sum(ref >= observed)
  p <- (1 + n_upper) / (1 + n_valid)
  list(p = p, n_upper = as.integer(n_upper), n_valid = n_valid,
       mcse = sqrt(p * (1 - p) / (n_valid + 1)))
}

#' Empirical percentile position of an observed value
#' @keywords internal
percentile_of <- function(observed, reference) {
  ref <- reference[is.finite(reference)]
  if (length(ref) == 0L || !is.finite(observed)) return(NA_real_)
  100 * mean(ref <= observed)
}

#' Validate a gene table used by the effect-level interface
#' @keywords internal
check_gene_table <- function(tbl, name) {
  if (!is.data.frame(tbl)) {
    stop(sprintf("`%s` must be a data.frame.", name), call. = FALSE)
  }
  if (!"gene" %in% names(tbl) || !"effect" %in% names(tbl)) {
    stop(sprintf("`%s` must contain columns `gene` and `effect`.", name), call. = FALSE)
  }
  allowed <- c("gene", "effect", "fdr", "hub", "eligible")
  extra <- setdiff(names(tbl), allowed)
  if (length(extra)) {
    stop(sprintf("`%s` has unsupported columns: %s.", name, paste(extra, collapse = ", ")),
         call. = FALSE)
  }
  tbl$gene <- trimws(as.character(tbl$gene))
  tbl$effect <- as.numeric(tbl$effect)
  if ("fdr" %in% names(tbl)) tbl$fdr <- as.numeric(tbl$fdr)
  if ("hub" %in% names(tbl)) tbl$hub <- as.logical(tbl$hub)
  if ("eligible" %in% names(tbl)) tbl$eligible <- as.logical(tbl$eligible)
  tbl <- tbl[nzchar(tbl$gene) & !duplicated(tbl$gene), , drop = FALSE]
  rownames(tbl) <- NULL
  tbl
}

#' Remove Y-chromosome genes and non-finite effects
#' @keywords internal
drop_technical <- function(tbl, exclude = .y_chromosome_genes) {
  tbl[is.finite(tbl$effect) & !tbl$gene %in% exclude, , drop = FALSE]
}
