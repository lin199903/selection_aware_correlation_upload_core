# selcorr 0.1.1

* Adds the archived 16-cell MASLD–AH recovery fixture.
* Adds recovery-regression tests covering grid identity, Monte Carlo SE calculation, archived monotonic observed-correlation progression across injected effect sizes, and frozen strongest-cell values.
* No API or core statistical definition changes from 0.1.0.

# selcorr 0.1.0

* First release. One core object: a construction-aware reference for
  post-selection correlation.
* `selcorr()` with an effect-level interface (`method = "gene_label"`) and a
  sample-level anchored replay interface (`method = "replay"`, Freedman-Lane
  residual permutation with model refitting and full selection reconstruction).
* `selection_spec()` makes the selection rule an explicit, recorded input
  (`fit$spec`), including the eligibility rule, magnitude thresholds and the
  direction rule.
* Diagnostic fixed-set comparator (`method = "fixed_set"`) flagged
  `diagnostic_only = TRUE`.
* `summary()` reports the observed correlation, the reference, the position of
  the observed value and the boundary of the statement; `plot()` draws one
  core figure.
* Subordinate helpers: `diagnose(type = "recovery")` and `validate()`.
* Deterministic draw sequences shared by serial and parallel execution,
  checkpoint/resume for long runs.
* Regression tests against archived frozen analyses (analytic geometry,
  OSA-MASLD, MASLD-MASLD, MASLD-AH series).
