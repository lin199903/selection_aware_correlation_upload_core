apply_selection <- selcorr:::apply_selection
summarise_reference <- selcorr:::summarise_reference

## Regression tests against archived, frozen analyses. These tests compare the
## package's statistics with the archived machine-readable outputs rather than
## re-running multi-hour replays. The heavy end-to-end replay check is marked
## slow and is skipped unless SELCORR_RUN_SLOW_TESTS is set.

archive_root <- function() {
  ## The archived analyses are not redistributed with the package, so the
  ## location is supplied by the caller. Set SELCORR_ARCHIVE_ROOT to a checkout
  ## of the reproducibility archive to run the archive-dependent tests; they are
  ## skipped otherwise.
  Sys.getenv("SELCORR_ARCHIVE_ROOT", unset = "")
}

read_archived_summary <- function(path) {
  if (!file.exists(path)) return(NULL)
  read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

read_archived_iterations <- function(path) {
  if (!file.exists(path)) return(NULL)
  read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

test_that("archived OSA-MASLD reference statistics are reproduced from archived draws", {
  root <- archive_root()
  it_path <- file.path(root, "reanalysis_20260722/outputs/phenotype_null/phenotype_null_iterations.csv")
  sm_path <- file.path(root, "reanalysis_20260722/outputs/phenotype_null/phenotype_null_summary.csv")
  skip_if_not(file.exists(it_path) && file.exists(sm_path), "archived OSA-MASLD outputs not available")
  it <- read_archived_iterations(it_path)
  sm <- read_archived_summary(sm_path)

  observed_r <- sm$ObservedSelectedPearson[1]
  stats <- summarise_reference(
    data.frame(iteration = it$Iteration, converged = it$Converged,
               r = it$SelectedPearson, eligible = it$EligiblePoolGenes,
               selected = it$SameSignSelectedGenes, common = it$CommonGenes,
               error = NA_character_, stringsAsFactors = FALSE),
    observed_r)

  ## Frozen values from the analysed manuscript.
  expect_equal(observed_r, 0.551, tolerance = 0.002)
  expect_equal(sm$ObservedEligiblePoolGenes[1], 110)
  expect_equal(sm$ObservedSameSignSelectedGenes[1], 52)
  expect_equal(stats$null_mean, 0.668, tolerance = 0.003)
  expect_equal(stats$p_value, 0.922, tolerance = 0.005)
})

test_that("archived MASLD-MASLD reference statistics are reproduced from archived draws", {
  root <- archive_root()
  dir <- file.path(root, "v151_0_github_repo/validation_analyses/outputs/masld_samedisease")
  it_files <- list.files(dir, pattern = "^replay_iterations_.*csv$", full.names = TRUE)
  sm_files <- list.files(dir, pattern = "^replay_summary_.*csv$", full.names = TRUE)
  skip_if_not(length(it_files) > 0 && length(sm_files) > 0,
              "archived MASLD-MASLD outputs not available")

  checked <- 0L
  for (smf in sm_files) {
    sm <- read_archived_summary(smf)
    tag <- sub("^replay_summary_", "", sub("\\.csv$", "", basename(smf)))
    it <- read_archived_iterations(file.path(dir, paste0("replay_iterations_", tag, ".csv")))
    if (is.null(it)) next
    stats <- summarise_reference(
      data.frame(iteration = it$Iteration, converged = it$Converged,
                 r = it$SelectedPearson, eligible = it$EligiblePoolGenes,
                 selected = it$SameSignSelectedGenes, common = it$CommonGenes,
                 error = NA_character_, stringsAsFactors = FALSE),
      sm$ObservedSelectedPearson[1])
    expect_equal(stats$null_mean, sm$NullMeanPearson[1], tolerance = 1e-6)
    expect_equal(stats$p_value, sm$PUpperAddOne[1], tolerance = 1e-6)
    checked <- checked + 1L
  }
  expect_gt(checked, 0L)

  ## The frozen MASLD-MASLD values cited in the manuscript come from the
  ## archived positive-control summary, which is the analysis the text reports.
  frozen_path <- file.path(root,
    "reanalysis_20260722/outputs/positive_control_masld_masld/positive_control_summary.csv")
  if (file.exists(frozen_path)) {
    frozen <- read_archived_summary(frozen_path)
    expect_equal(frozen$ObservedSelectedPearson[1], 0.651, tolerance = 0.01)
    expect_equal(frozen$NullMeanPearson[1], 0.734, tolerance = 0.01)
    expect_equal(frozen$PUpperAddOne[1], 0.845, tolerance = 0.02)
  }
})

test_that("archived MASLD-AH replay series is reproduced from archived draws", {
  root <- archive_root()
  dir <- file.path(root, "learned/v151_9_MASLD_AH/output")
  sm_files <- list.files(dir, pattern = "^replay_summary_.*csv$", full.names = TRUE)
  skip_if_not(length(sm_files) > 0, "archived MASLD-AH outputs not available")

  for (smf in sm_files) {
    sm <- read_archived_summary(smf)
    tag <- sub("^replay_summary_", "", sub("\\.csv$", "", basename(smf)))
    it <- read_archived_iterations(file.path(dir, paste0("replay_iterations_", tag, ".csv")))
    if (is.null(it)) next
    stats <- summarise_reference(
      data.frame(iteration = it$Iteration, converged = it$Converged,
                 r = it$SelectedPearson, eligible = it$EligiblePoolGenes,
                 selected = it$SameSignSelectedGenes, common = it$CommonGenes,
                 error = NA_character_, stringsAsFactors = FALSE),
      sm$ObservedSelectedPearson[1])
    expect_equal(stats$null_mean, sm$NullMeanPearson[1], tolerance = 1e-6)
    expect_equal(stats$null_sd, sm$NullSDPearson[1], tolerance = 1e-6)
    expect_equal(stats$p_value, sm$PUpperAddOne[1], tolerance = 1e-6)
    expect_gt(sm$ObservedSelectedPearson[1], 0)
  }
})

test_that("slow: sample-level replay on archived inputs reproduces the frozen observed statistics", {
  skip_if_not(nzchar(Sys.getenv("SELCORR_RUN_SLOW_TESTS")),
              "set SELCORR_RUN_SLOW_TESTS=1 to run the end-to-end replay check")
  root <- archive_root()
  osa_path <- file.path(root, "reanalysis_20260722/data/derived/GSE135917_rebuilt.rds")
  masld_de_path <- file.path(root, "reanalysis_20260722/outputs/de/GSE126848_DESeq2_primary.csv")
  hub_path <- file.path(root, "reanalysis_20260722/outputs/network/MASLD_topology_hubs_primary.csv")
  osa_hub_path <- file.path(root, "reanalysis_20260722/outputs/osa_network/OSA_topology_hubs_primary.csv")
  skip_if_not(all(file.exists(c(osa_path, masld_de_path, hub_path, osa_hub_path))),
              "archived OSA-MASLD inputs not available")

  osa <- readRDS(osa_path)
  de <- read.csv(masld_de_path, check.names = FALSE)
  x <- data.frame(gene = de$Gene, effect = as.numeric(de$log2FoldChange),
                  fdr = as.numeric(de$padj),
                  hub = de$Gene %in% read.csv(hub_path, check.names = FALSE)$Gene)
  y <- list(expr = osa$discovery_expression, group = osa$discovery_coldata$group,
            covariates = osa$discovery_coldata[, c("age_z", "bmi_z", "sex")],
            tbl = data.frame(gene = rownames(osa$discovery_expression), effect = 0)  # placeholder, refit below
  )
  y$tbl <- NULL
  ## observed only: B = 0 keeps the run short and still exercises the pipeline
  fit <- selcorr(x, y, selection = selection_spec("hub_de"),
                 method = "replay", B = 0, seed = 1, verbose = FALSE)
  expect_equal(fit$observed_r, 0.551, tolerance = 0.005)
  expect_equal(fit$n_eligible, 110)
  expect_equal(fit$n_selected, 52)
})
