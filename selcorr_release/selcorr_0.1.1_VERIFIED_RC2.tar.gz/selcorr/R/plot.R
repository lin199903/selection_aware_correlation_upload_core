#' Plot the construction-aware reference
#'
#' One core figure: the replay distribution, the reference centre, the 95%
#' critical value and the observed correlation. For the diagnostic fixed-set
#' comparator the same figure is drawn with a clear label, because that
#' comparator does not regenerate selection.
#'
#' @param x A \code{selcorr} object.
#' @param ... Graphical parameters passed to \code{hist}.
#' @return The object, invisibly.
#' @export
plot.selcorr <- function(x, ...) {
  ref <- x$replay_statistics$r[x$replay_statistics$converged & is.finite(x$replay_statistics$r)]
  if (!length(ref)) stop("No valid reference draws to plot.", call. = FALSE)
  label <- if (isTRUE(x$diagnostic_only)) {
    "Fixed-set diagnostic comparator (selection not regenerated)"
  } else {
    sprintf("Construction-aware %s reference", x$method)
  }
  graphics::hist(ref, breaks = 40, col = "#D9EAF4", border = "white",
                 xlab = "Selected-set Pearson r", main = label, ...)
  graphics::abline(v = x$null_mean, col = "#2166AC", lwd = 2, lty = 3)
  graphics::abline(v = x$critical_value, col = "#1B7837", lwd = 2, lty = 4)
  graphics::abline(v = x$observed_r, col = "#B2182B", lwd = 2.5, lty = 2)
  graphics::legend("topleft", bty = "n", lwd = c(2.5, 2, 2),
                   lty = c(2, 3, 4), col = c("#B2182B", "#2166AC", "#1B7837"),
                   legend = c(sprintf("Observed r = %.3f", x$observed_r),
                              sprintf("Reference mean = %.3f", x$null_mean),
                              sprintf("95%% critical = %.3f", x$critical_value)))
  invisible(x)
}
