## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(selcorr)

## -----------------------------------------------------------------------------
set.seed(10)
n_gene <- 400; n_case <- 10; n_ctrl <- 12
genes <- sprintf("G%04d", seq_len(n_gene))
group <- factor(c(rep("case", n_case), rep("control", n_ctrl)),
                levels = c("control", "case"))
expr <- matrix(rnorm(n_gene * (n_case + n_ctrl)), nrow = n_gene,
               dimnames = list(genes, NULL))

## Anchored arm: effects and FDRs, plus a topology-derived hub flag.
anchored <- data.frame(
  gene = genes,
  effect = c(rnorm(80, 0.9), rnorm(n_gene - 80, 0.1)),
  fdr = c(runif(80, 0, 0.01), runif(n_gene - 80, 0, 0.6)),
  hub = seq_len(n_gene) %% 4 == 0
)

fit <- selcorr(
  anchored,
  list(expr = expr, group = group),
  selection = selection_spec("de_anchor"),
  method = "replay",
  B = 200,
  seed = 2026,
  verbose = FALSE
)
fit

## -----------------------------------------------------------------------------
fit$spec$selection
round(c(observed_r = fit$observed_r, eligible = fit$n_eligible,
        selected = fit$n_selected, reference_mean = fit$null_mean,
        reference_sd = fit$null_sd, critical_95 = fit$critical_value,
        percentile = fit$observed_percentile, upper_p = fit$p_value), 4)

## -----------------------------------------------------------------------------
summary(fit)

## ----fig.height = 3.4, fig.width = 5.2----------------------------------------
plot(fit)

## ----eval = FALSE-------------------------------------------------------------
# fit <- selcorr(
#   anchored, arm,
#   selection = selection_spec("de_anchor"),
#   method = "replay",
#   B = 2000,
#   seed = 1,
#   checkpoint = "checkpoints/primary_pair.rds",
#   resume = TRUE,
#   parallel = TRUE
# )

## ----eval = FALSE-------------------------------------------------------------
# rec <- diagnose(fit, type = "recovery",
#                 fractions = c(0.05, 0.10, 0.25, 0.50),
#                 effect_sizes = c(0.2, 0.4, 0.6, 1.0),
#                 n_outer = 30, n_perm = 100)
# rec

## ----eval = FALSE-------------------------------------------------------------
# val <- validate(fit, x_new, y_new, n_perm = 2000)
# val

