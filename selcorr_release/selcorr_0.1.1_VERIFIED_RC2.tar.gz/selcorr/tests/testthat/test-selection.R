apply_selection <- selcorr:::apply_selection

test_that("selection_spec records the workflow explicitly", {
  spec <- selection_spec("de_anchor", fdr_cut = 0.05, abs_effect_cut = 0.3)
  expect_s3_class(spec, "selcorr_selection")
  expect_identical(spec$eligibility, "de_anchor")
  expect_identical(spec$direction_rule, "same_sign")
  expect_equal(spec$magnitude_rule$fdr_cut, 0.05)
  expect_equal(spec$magnitude_rule$abs_effect_cut, 0.3)
  expect_output(print(spec), "de_anchor")
})

test_that("unsupported direction rules are rejected", {
  expect_error(selection_spec("de_anchor", direction = "either_sign"))
})

test_that("de_anchor eligibility uses the anchored arm's DE genes", {
  tbl <- data.frame(
    gene = sprintf("G%02d", 1:6),
    effect_x = c(1.0, -1.0, 0.5, 0.1, 2.0, -0.2),
    fdr_x = c(0.01, 0.01, 0.02, 0.5, 0.001, 0.04),
    effect_y = c(0.8, -0.9, -0.4, 0.2, 1.5, 0.3),
    fdr_y = c(0.01, 0.01, 0.02, 0.5, 0.001, 0.04),
    stringsAsFactors = FALSE)
  spec <- selection_spec("de_anchor")
  res <- apply_selection(spec, tbl)
  ## |effect| > 0.3 and FDR < 0.05 in the anchored arm selects G01, G02, G03, G05
  ## (G06 has FDR < 0.05 but |effect| = 0.2, so it does not qualify)
  expect_equal(res$eligible, 4L)
  ## same-sign among those: G01, G02, G05 (G03 and G06 flip sign)
  expect_equal(res$selected, 3L)
  expect_setequal(res$selected_genes, c("G01", "G02", "G05"))
})

test_that("hub_de eligibility requires hub membership on one side and DE on the other", {
  tbl <- data.frame(
    gene = c("A", "B", "C", "D"),
    effect_x = c(1, -1, 0.5, 0.05),
    fdr_x = c(0.01, 0.01, 0.5, 0.01),
    hub_x = c(FALSE, TRUE, FALSE, TRUE),
    effect_y = c(0.9, 0.8, -0.4, 0.6),
    fdr_y = c(0.5, 0.5, 0.01, 0.01),
    hub_y = c(TRUE, FALSE, TRUE, FALSE),
    stringsAsFactors = FALSE)
  res <- apply_selection(selection_spec("hub_de"), tbl)
  ## A: hub_y & DE_x -> eligible
  ## B: hub_x & DE_y? DE_y FDR 0.5 -> not eligible
  ## C: hub_y & DE_x? DE_x FDR 0.5 -> not eligible
  ## D: hub_x & DE_y -> eligible
  expect_setequal(res$pool_genes, c("A", "D"))
})

test_that("hub_de requires hub columns", {
  tbl <- data.frame(gene = "A", effect_x = 1, fdr_x = 0.01,
                    effect_y = 1, fdr_y = 0.01, stringsAsFactors = FALSE)
  expect_error(apply_selection(selection_spec("hub_de"), tbl), "hub_de")
})

test_that("eligibility callbacks are honoured", {
  tbl <- data.frame(gene = c("A", "B"), effect_x = c(1, 2), fdr_x = c(0.01, 0.01),
                    effect_y = c(1, 2), fdr_y = c(0.01, 0.01), stringsAsFactors = FALSE)
  spec <- selection_spec(function(d) d$gene == "A")
  res <- apply_selection(spec, tbl)
  expect_equal(res$eligible, 1L)
  expect_identical(res$selected_genes, "A")
})

test_that("excluded genes and non-finite effects never enter the pool", {
  tbl <- data.frame(gene = c("UTY", "A"), effect_x = c(5, 1), fdr_x = c(0.001, 0.01),
                    effect_y = c(5, 1), fdr_y = c(0.001, 0.01), stringsAsFactors = FALSE)
  res <- apply_selection(selection_spec("de_anchor"), tbl)
  expect_identical(res$pool_genes, "A")
})

test_that("too few selected genes yield an undefined correlation", {
  tbl <- data.frame(gene = c("A", "B"), effect_x = c(1, 2), fdr_x = c(0.01, 0.01),
                    effect_y = c(1, 2), fdr_y = c(0.01, 0.01), stringsAsFactors = FALSE)
  res <- apply_selection(selection_spec("de_anchor", min_selected = 4L), tbl)
  expect_true(is.na(res$r))
})
