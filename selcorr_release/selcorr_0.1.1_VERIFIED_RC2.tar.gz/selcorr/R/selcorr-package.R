#' selcorr: construction-aware references for post-selection correlation
#'
#' The package has one core object: a construction-aware reference for
#' correlations computed after agreement-based feature selection. Two further
#' functions are deliberately subordinate to that core object:
#' \code{diagnose()} describes the recovery boundary of a calibrated endpoint,
#' and \code{validate()} checks whether the selected object carries portable
#' alignment in independent data.
#'
#' @section Scientific wording:
#' Documentation in this package does not claim that a reference removes all
#' selection effects, that a null result proves absence of biological sharing,
#' or that the resulting correlation is unbiased or universally valid. A
#' result concerns the selected-correlation endpoint under the specified
#' workflow.
#'
#' @keywords internal
"_PACKAGE"
