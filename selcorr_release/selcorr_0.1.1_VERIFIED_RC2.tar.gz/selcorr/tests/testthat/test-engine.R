test_that("gene-label replay returns a full set of draws and summary fields", {
  set.seed(42)
  genes <- sprintf("G%03d", 1:500)
  x <- data.frame(gene = genes, effect = rnorm(500),
                  fdr = runif(500, 0, 0.5), stringsAsFactors = FALSE)
  y <- data.frame(gene = genes, effect = rnorm(500),
                  fdr = runif(500, 0, 0.5), stringsAsFactors = FALSE)
  fit <- selcorr(x, y, selection = selection_spec("de_anchor"),
                 method = "gene_label", B = 40, seed = 7, verbose = FALSE)
  expect_s3_class(fit, "selcorr")
  for (f in c("observed_r", "n_common", "n_eligible", "n_selected", "selected_fraction",
              "null_mean", "null_sd", "null_median", "null_q025", "null_q95",
              "critical_value", "observed_percentile", "z_position", "p_value",
              "selected_genes", "replay_statistics", "spec", "seed", "B")) {
    expect_true(f %in% names(fit), info = f)
  }
  expect_equal(nrow(fit$replay_statistics), 40L)
  expect_gte(fit$p_value, 0)
  expect_lte(fit$p_value, 1)
  expect_true(is.na(fit$diagnostic_only) || isFALSE(fit$diagnostic_only))
})

test_that("fixed-set comparator is flagged diagnostic_only", {
  set.seed(11)
  genes <- sprintf("G%03d", 1:300)
  x <- data.frame(gene = genes, effect = rnorm(300), fdr = runif(300, 0, 0.4))
  y <- data.frame(gene = genes, effect = rnorm(300), fdr = runif(300, 0, 0.4))
  fit <- selcorr(x, y, selection = selection_spec("de_anchor"),
                 method = "fixed_set", B = 30, seed = 3, verbose = FALSE)
  expect_true(fit$diagnostic_only)
  expect_output(print(fit), "diagnostic")
})

test_that("sample-level replay reproduces the archived Freedman-Lane mechanics", {
  ## A small synthetic sample-level problem: two groups, no real disease effect.
  set.seed(5)
  n_case <- 8L; n_ctrl <- 8L; n_gene <- 300L
  genes <- sprintf("G%03d", seq_len(n_gene))
  group <- factor(c(rep("case", n_case), rep("control", n_ctrl)),
                  levels = c("control", "case"))
  expr <- matrix(rnorm(n_gene * (n_case + n_ctrl)), nrow = n_gene,
                 dimnames = list(genes, NULL))
  ## Anchored arm: a subset is "DE" so that the pool is non-empty.
  x <- data.frame(gene = genes,
                  effect = c(rnorm(60, 0.8), rnorm(n_gene - 60, 0.1)),
                  fdr = c(runif(60, 0, 0.01), runif(n_gene - 60, 0, 0.6)))
  fit <- selcorr(x, list(expr = expr, group = group), selection = selection_spec("de_anchor"),
                 method = "replay", B = 25, seed = 9, verbose = FALSE)
  expect_s3_class(fit, "selcorr")
  expect_identical(fit$method, "replay")
  expect_equal(nrow(fit$replay_statistics), 25L)
  ## With no true group effect the observed correlation should sit inside the reference.
  expect_lt(abs(fit$z_position), 4)
})

test_that("method = replay without expression data fails with a clear message", {
  genes <- sprintf("G%03d", 1:100)
  x <- data.frame(gene = genes, effect = rnorm(100), fdr = runif(100, 0, 0.3))
  y <- data.frame(gene = genes, effect = rnorm(100), fdr = runif(100, 0, 0.3))
  expect_error(selcorr(x, y, selection = selection_spec("de_anchor"),
                       method = "replay", B = 5, verbose = FALSE),
               "requires the replayed arm to provide")
})

test_that("bidirectional runs keep two separate estimands", {
  set.seed(21)
  genes <- sprintf("G%03d", 1:200)
  x <- data.frame(gene = genes, effect = rnorm(200), fdr = runif(200, 0, 0.3))
  y <- data.frame(gene = genes, effect = rnorm(200, 0.2), fdr = runif(200, 0, 0.3))
  both <- selcorr_bidir(x, y, selection = selection_spec("de_anchor"),
                        method = "gene_label", B = 20, seed = 2, verbose = FALSE)
  expect_s3_class(both, "selcorr_bidir")
  expect_identical(both$forward$spec$anchor, "x")
  expect_identical(both$reverse$spec$anchor, "y")
  expect_false(isTRUE(all.equal(both$forward$null_mean, both$reverse$null_mean)))
  expect_output(print(both), "never averaged")
})
