## Checkpoint / resume. Long replays write progress every `checkpoint_every`
## iterations so an interrupted run resumes rather than restarting.

new_replay_state <- function(checkpoint, resume, B) {
  empty <- data.frame(iteration = integer(0), converged = logical(0), r = numeric(0),
                      eligible = integer(0), selected = integer(0), common = integer(0),
                      error = character(0), stringsAsFactors = FALSE)
  if (!is.null(checkpoint) && isTRUE(resume) && file.exists(checkpoint)) {
    state <- tryCatch(readRDS(checkpoint), error = function(e) NULL)
    if (!is.null(state) && is.data.frame(state$iterations)) {
      message(sprintf("  resuming from checkpoint: %d draws already complete",
                      nrow(state$iterations)))
      return(list(iterations = state$iterations))
    }
  }
  list(iterations = empty)
}

write_checkpoint <- function(checkpoint, iterations, meta) {
  if (is.null(checkpoint)) return(invisible(NULL))
  dir <- dirname(checkpoint)
  if (!dir.exists(dir)) dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  saveRDS(list(iterations = iterations, meta = meta, saved_at = Sys.time()),
          checkpoint)
  invisible(NULL)
}
