## Estimator adapters. The package does not reimplement differential
## expression: it calls the same estimators as the archived workflows
## (limma with trend = TRUE and robust = TRUE; DESeq2 with the stated design).

#' Build a limma effect fitter
#'
#' @param expr Numeric matrix, genes in rows.
#' @param design_full Full design matrix (must contain the group coefficient).
#' @param coef_pattern Regular expression selecting the group coefficient.
#' @return A function that maps an expression matrix to a data frame with
#'   columns \code{gene}, \code{effect} and \code{fdr}.
#' @export
estimator_limma <- function(expr, design_full, coef_pattern = "^group") {
  coef <- grep(coef_pattern, colnames(design_full), value = TRUE)[1L]
  if (is.na(coef)) {
    stop("No coefficient matching `coef_pattern` in the design matrix.", call. = FALSE)
  }
  function(expression_matrix) {
    fit <- limma::eBayes(limma::lmFit(expression_matrix, design_full),
                         trend = TRUE, robust = TRUE)
    tt <- limma::topTable(fit, coef = coef, number = Inf, sort.by = "none")
    data.frame(gene = rownames(tt), effect = as.numeric(tt$logFC),
               fdr = as.numeric(tt$adj.P.Val), stringsAsFactors = FALSE)
  }
}

#' Build a DESeq2 effect fitter
#'
#' Provided for completeness; the archived sample-level workflows used limma on
#' a variance-stabilised matrix. Estimator substitution is an analysis choice
#' and should be reported as such.
#'
#' @param counts Integer count matrix, genes in rows.
#' @param colData Data frame of sample metadata, rows aligned to columns of
#'   \code{counts}.
#' @param design Formula for the DESeq2 design, e.g. \code{~ group}.
#' @param contrast Character vector of length three, e.g.
#'   \code{c("group", "case", "control")}.
#' @return A function that maps a count matrix to a data frame with columns
#'   \code{gene}, \code{effect} and \code{fdr}.
#' @export
estimator_deseq2 <- function(counts, colData, design = ~group,
                             contrast = c("group", "case", "control")) {
  if (!requireNamespace("DESeq2", quietly = TRUE)) {
    stop("Estimator \"DESeq2\" requires the DESeq2 package.", call. = FALSE)
  }
  function(count_matrix) {
    count_matrix <- round(as.matrix(count_matrix))
    storage.mode(count_matrix) <- "integer"
    dds <- DESeq2::DESeqDataSetFromMatrix(countData = count_matrix,
                                          colData = colData, design = design)
    dds <- DESeq2::DESeq(dds, quiet = TRUE)
    res <- DESeq2::results(dds, contrast = contrast)
    data.frame(gene = rownames(res), effect = as.numeric(res$log2FoldChange),
               fdr = as.numeric(res$padj), stringsAsFactors = FALSE)
  }
}

## Internal: resolve an arm specification into expression, designs and a
## fitted-effect function, caching everything that does not change across
## replay iterations.
prepare_sample_arm <- function(arm, name) {
  if (is.null(arm$expr)) {
    stop(sprintf("Arm `%s` must provide `expr` for sample-level replay.", name), call. = FALSE)
  }
  expr <- as.matrix(arm$expr)
  group <- arm$group
  if (is.null(group)) {
    stop(sprintf("Arm `%s` must provide `group`.", name), call. = FALSE)
  }
  group <- factor(group)
  covariates <- arm$covariates
  design_full <- arm$design_full
  design_nuisance <- arm$design_nuisance
  if (is.null(design_full) || is.null(design_nuisance)) {
    cd <- data.frame(group = group)
    if (!is.null(covariates)) cd <- cbind(cd, as.data.frame(covariates))
    design_full <- if (is.null(covariates)) {
      stats::model.matrix(~group, data = cd)
    } else {
      stats::model.matrix(stats::as.formula(paste("~", paste(c(colnames(covariates), "group"), collapse = " + "))),
                          data = cd)
    }
    design_nuisance <- if (is.null(covariates)) {
      matrix(1, nrow = nrow(cd), ncol = 1L)
    } else {
      stats::model.matrix(stats::as.formula(paste("~", paste(colnames(covariates), collapse = " + "))),
                          data = cd)
    }
  }
  if (nrow(design_full) != ncol(expr)) {
    stop(sprintf("Arm `%s`: design has %d rows but `expr` has %d columns.",
                 name, nrow(design_full), ncol(expr)), call. = FALSE)
  }
  estimator <- arm$estimator %||% "limma"
  fit_fun <- if (is.function(arm$fit_fun)) {
    arm$fit_fun
  } else if (identical(estimator, "limma")) {
    estimator_limma(expr, design_full,
                    coef_pattern = arm$coef_pattern %||% "^group")
  } else if (identical(estimator, "DESeq2")) {
    stop("Sample-level replay with estimator = \"DESeq2\" requires an explicit `fit_fun`.",
         call. = FALSE)
  } else {
    stop(sprintf("Unknown estimator: %s", estimator), call. = FALSE)
  }

  fit_nuisance <- limma::lmFit(expr, design_nuisance)
  fitted_nuisance <- fit_nuisance$coefficients %*% t(design_nuisance)
  residuals <- expr - fitted_nuisance

  list(
    name = name, expr = expr, group = group,
    design_full = design_full, design_nuisance = design_nuisance,
    fit_fun = fit_fun, fitted = fitted_nuisance, residuals = residuals,
    estimator = estimator, n_samples = ncol(expr)
  )
}

`%||%` <- function(a, b) if (is.null(a)) b else a
