#' Run both anchoring directions
#'
#' Convenience helper that calls \code{\link{selcorr}} twice, once with each arm
#' anchored. The two results are separate estimands: the null centre, the
#' dispersion and the p value are reported per direction and are never averaged
#' or combined.
#'
#' @inheritParams selcorr
#' @return A list of class \code{selcorr_bidir} with elements \code{forward}
#'   (x anchored) and \code{reverse} (y anchored).
#' @export
selcorr_bidir <- function(x, y, selection = selection_spec(),
                          method = c("replay", "gene_label", "fixed_set"),
                          B = 2000L, seed = 1L, checkpoint = NULL,
                          checkpoint_every = 50L, resume = FALSE,
                          parallel = FALSE, verbose = TRUE) {
  method <- match.arg(method)
  forward <- selcorr(x, y, selection = selection, anchor = "x", method = method,
                     B = B, seed = seed, checkpoint = checkpoint,
                     checkpoint_every = checkpoint_every, resume = resume,
                     parallel = parallel, verbose = verbose)
  reverse <- selcorr(x, y, selection = selection, anchor = "y", method = method,
                     B = B, seed = seed + 1L, checkpoint = checkpoint,
                     checkpoint_every = checkpoint_every, resume = resume,
                     parallel = parallel, verbose = verbose)
  out <- list(forward = forward, reverse = reverse)
  class(out) <- "selcorr_bidir"
  out
}

#' @export
print.selcorr_bidir <- function(x, ...) {
  cat("<selcorr bidirectional run>\n")
  cat("Two separate direction-specific estimands (never averaged):\n\n")
  for (nm in c("forward", "reverse")) {
    f <- x[[nm]]
    cat(sprintf("  %-8s anchored = %s : observed r = %.4f, reference mean = %.4f (SD %.4f), percentile = %.1f, upper P = %.4f\n",
                nm, f$spec$anchor, f$observed_r, f$null_mean, f$null_sd,
                f$observed_percentile, f$p_value))
  }
  invisible(x)
}
