#' Independent-evaluation validation of a selected gene set
#'
#' Evaluates the selected gene set in data that took no part in selection. The
#' gene set is treated as externally fixed, and the evaluation reference does
#' not replay the original selection; the function therefore asks whether the
#' object carries portable alignment, not whether the original correlation was
#' calibrated. Its p value is never combined with the replay p value.
#'
#' @param fit A \code{selcorr} object.
#' @param x_new,y_new Independent arms, in either supported input form.
#' @param n_perm Reference draws for the evaluation side.
#' @param seed Integer seed.
#' @param parallel Use \pkg{future.apply}.
#' @param verbose Print progress.
#' @return A data frame with \code{n_eval_common}, \code{n_eval_selected},
#'   \code{evaluation_r}, \code{null_mean}, \code{null_sd},
#'   \code{critical_value}, \code{percentile} and \code{p_value}.
#' @export
validate <- function(fit, x_new, y_new, n_perm = 2000L, seed = 1L,
                     parallel = FALSE, verbose = TRUE) {
  if (!inherits(fit, "selcorr")) stop("`fit` must be a selcorr object.", call. = FALSE)
  ax <- .as_arm(x_new, "x_new")
  ay <- .as_arm(y_new, "y_new")
  selected <- fit$selected_genes
  if (!length(selected)) stop("The fit has no selected genes to validate.", call. = FALSE)

  eval_effects <- function(arm) {
    tbl <- arm$tbl
    tbl[!duplicated(tbl$gene), c("gene", "effect"), drop = FALSE]
  }
  ex <- eval_effects(ax); ey <- eval_effects(ay)
  common <- merge(ex, ey, by = "gene", all = FALSE, sort = FALSE)
  common <- common[is.finite(common$effect.x) & is.finite(common$effect.y), , drop = FALSE]
  in_set <- common[common$gene %in% selected, , drop = FALSE]
  r_eval <- safe_cor(in_set$effect.x, in_set$effect.y, fit$spec$selection$min_selected)

  nulls <- numeric(0)
  if (identical(ay$kind, "sample")) {
    prep <- ay$prepared
    design_n <- matrix(1, nrow = prep$n_samples, ncol = 1L)
    f_n <- limma::lmFit(prep$expr, design_n)
    fitted <- f_n$coefficients %*% t(design_n)
    residuals <- prep$expr - fitted
    set.seed(seed)
    perms <- replicate(n_perm, sample.int(prep$n_samples), simplify = FALSE)
    eval_one <- function(pm) {
      tbl <- prep$fit_fun(fitted + residuals[, pm, drop = FALSE])
      m <- merge(ex, data.frame(gene = tbl$gene, effect = tbl$effect), by = "gene", all = FALSE)
      s <- m[m$gene %in% selected & is.finite(m$effect.x) & is.finite(m$effect.y), , drop = FALSE]
      safe_cor(s$effect.x, s$effect.y, fit$spec$selection$min_selected)
    }
    nulls <- if (parallel && requireNamespace("future.apply", quietly = TRUE)) {
      unlist(future.apply::future_lapply(perms, eval_one, future.seed = TRUE))
    } else {
      vapply(perms, eval_one, numeric(1))
    }
  } else {
    ## Effect-level evaluation: gene-label permutation within the externally
    ## fixed selected set, so the set itself never changes.
    set.seed(seed)
    n <- nrow(in_set)
    perms <- replicate(n_perm, sample.int(n), simplify = FALSE)
    nulls <- vapply(perms, function(pm) {
      shuffled <- in_set
      shuffled$effect.y <- in_set$effect.y[pm]
      safe_cor(shuffled$effect.x, shuffled$effect.y, fit$spec$selection$min_selected)
    }, numeric(1))
  }

  ref <- nulls[is.finite(nulls)]
  p_info <- add_one_upper_p(r_eval, ref)
  q <- if (length(ref)) stats::quantile(ref, 0.95, na.rm = TRUE) else NA_real_
  out <- data.frame(
    n_eval_common = nrow(common),
    n_eval_selected = nrow(in_set),
    evaluation_r = r_eval,
    null_mean = if (length(ref)) mean(ref) else NA_real_,
    null_sd = if (length(ref)) stats::sd(ref) else NA_real_,
    critical_value = unname(q),
    percentile = percentile_of(r_eval, ref),
    p_value = p_info$p,
    n_reference_valid = length(ref),
    stringsAsFactors = FALSE)
  if (verbose) {
    message(sprintf("  validation: evaluation r = %.4f, reference centre = %.4f, percentile = %.1f",
                    out$evaluation_r, out$null_mean, out$percentile))
  }
  attr(out, "note") <- paste(
    "The evaluation reference does not replay the original selection;",
    "this p value is not combined with the replay p value.")
  out
}
