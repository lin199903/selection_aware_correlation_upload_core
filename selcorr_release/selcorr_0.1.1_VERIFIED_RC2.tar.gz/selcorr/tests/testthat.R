library(testthat)
library(selcorr)

test_check("selcorr")
