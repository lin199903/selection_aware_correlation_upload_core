## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(selcorr)

## -----------------------------------------------------------------------------
set.seed(1)
n <- 2e5
x <- rnorm(n); y <- rnorm(n)
keep <- x * y > 0
round(cor(x[keep], y[keep]), 4)
same_sign_population_correlation()

## -----------------------------------------------------------------------------
q <- c(1, 0.9, 0.75, 0.5, 0.25, 0.1)
data.frame(q = q, population_r = round(analytic_selected_correlation(q), 4))

## ----fig.height = 3.2, fig.width = 5------------------------------------------
qs <- seq(1, 0.05, by = -0.01)
plot(qs, analytic_selected_correlation(qs), type = "l", lwd = 2,
     xlab = "Fraction retained by each study (q)", ylab = "Population correlation",
     main = "Reference induced by agreement plus magnitude selection")
abline(h = 2 / pi, lty = 3, col = "grey40")

## -----------------------------------------------------------------------------
set.seed(2)
genes <- sprintf("G%04d", 1:2000)
effect_y <- rnorm(2000)
x <- data.frame(gene = genes, effect = rnorm(2000), fdr = runif(2000, 0, 1))
y <- data.frame(gene = genes, effect = effect_y, fdr = runif(2000, 0, 1))

naive <- selcorr(x, y, selection = selection_spec("de_anchor"),
                 method = "fixed_set", B = 500, seed = 1, verbose = FALSE)
naive$diagnostic_only
round(c(observed = naive$observed_r, reference_mean = naive$null_mean,
        upper_p = naive$p_value), 4)

## ----eval = FALSE-------------------------------------------------------------
# fit <- selcorr(x, sample_level_arm, selection = selection_spec("de_anchor"),
#                method = "replay", B = 2000)
# summary(fit)
# plot(fit)

