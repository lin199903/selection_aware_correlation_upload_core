## Replay engine. Two reference constructions are implemented, plus one
## diagnostic comparator. Statistical definitions follow the archived
## production scripts; see inst/provenance/PACKAGE_PROVENANCE_MAP.md.

## Deterministic permutation indices are generated up front so that serial and
## parallel execution consume exactly the same draws.
generate_sample_perms <- function(B, n_samples, seed) {
  set.seed(seed)
  replicate(B, sample.int(n_samples), simplify = FALSE)
}

generate_gene_perms <- function(B, n_genes, seed) {
  set.seed(seed)
  replicate(B, sample.int(n_genes), simplify = FALSE)
}

#' Anchored construction-aware replay
#'
#' The anchored arm contributes fixed effects and, when the eligibility rule
#' requires it, fixed topology-derived sets. The replayed arm has its
#' disease-dependent steps regenerated: phenotype-null generation by
#' Freedman-Lane residual permutation, model refitting, differential-expression
#' filtering, eligibility reconstruction, same-sign selection and the selected
#' correlation. Every draw is therefore a complete pass through the same
#' selection workflow.
#'
#' @param fixed_tbl Data frame with columns \code{gene}, \code{effect},
#'   \code{fdr} and optionally \code{hub} for the anchored arm.
#' @param replayed_arm Prepared sample-level arm (see \code{\link{selcorr}}).
#' @param spec A \code{selcorr_selection} object.
#' @param B Number of replay draws.
#' @param seed Integer seed for the draw sequence.
#' @param checkpoint Optional path to an \code{.rds} checkpoint file.
#' @param checkpoint_every Checkpoint interval in iterations.
#' @param resume Resume from an existing checkpoint when present.
#' @param parallel Use \pkg{future.apply} for the draws.
#' @param verbose Print progress.
#' @return A list with \code{iterations} (one row per draw) and metadata.
#' @keywords internal
replay_anchored <- function(fixed_tbl, replayed_arm, spec, B,
                            seed = 1L, checkpoint = NULL, checkpoint_every = 50L,
                            resume = FALSE, parallel = FALSE, verbose = TRUE) {
  perms <- generate_sample_perms(B, replayed_arm$n_samples, seed)
  state <- new_replay_state(checkpoint, resume, B)
  iterations <- state$iterations

  one_draw <- function(i) {
    null_expr <- replayed_arm$fitted + replayed_arm$residuals[, perms[[i]], drop = FALSE]
    replayed_tbl <- tryCatch(replayed_arm$fit_fun(null_expr), error = function(e) NULL)
    if (is.null(replayed_tbl)) {
      return(data.frame(iteration = i, converged = FALSE, r = NA_real_,
                        eligible = NA_integer_, selected = NA_integer_,
                        common = NA_integer_, error = "fit_failed",
                        stringsAsFactors = FALSE))
    }
    replayed_tbl <- check_gene_table(replayed_tbl, "replayed")
    tbl <- pair_arms(fixed_tbl, replayed_tbl)
    res <- apply_selection(spec, tbl)
    data.frame(iteration = i, converged = TRUE, r = res$r,
               eligible = res$eligible, selected = res$selected,
               common = res$common, error = NA_character_,
               stringsAsFactors = FALSE)
  }

  todo <- setdiff(seq_len(B), iterations$iteration)
  if (length(todo)) {
    chunks <- split(todo, ceiling(seq_along(todo) / max(1L, checkpoint_every)))
    for (chunk in chunks) {
      rows <- if (parallel && requireNamespace("future.apply", quietly = TRUE)) {
        future.apply::future_lapply(chunk, one_draw, future.seed = TRUE)
      } else {
        lapply(chunk, one_draw)
      }
      new_rows <- do.call(rbind, rows)
      iterations <- rbind(iterations, new_rows)
      iterations <- iterations[order(iterations$iteration), , drop = FALSE]
      write_checkpoint(checkpoint, iterations, list(seed = seed, B = B))
      if (verbose) {
        message(sprintf("  replay %d/%d draws complete", max(iterations$iteration), B))
      }
    }
  }
  list(iterations = iterations, perms = perms, seed = seed, B = B)
}

#' Gene-label replay (effect-level interface)
#'
#' Available when the replayed arm is supplied only as effects. The
#' replayed-arm effects are permuted across genes, and the selection workflow
#' is reapplied. This preserves the magnitude structure of the replayed arm but
#' not its dependence structure or pool construction; the sample-level replay
#' is the primary construction-aware reference.
#'
#' @inheritParams replay_anchored
#' @param replayed_tbl Data frame with columns \code{gene}, \code{effect},
#'   \code{fdr} and optionally \code{hub} for the replayed arm.
#' @return A list with \code{iterations} and metadata.
#' @keywords internal
replay_gene_label <- function(fixed_tbl, replayed_tbl, spec, B,
                              seed = 1L, checkpoint = NULL, checkpoint_every = 50L,
                              resume = FALSE, parallel = FALSE, verbose = TRUE) {
  aligned <- pair_arms(fixed_tbl, replayed_tbl)
  n <- nrow(aligned)
  perms <- generate_gene_perms(B, n, seed)
  state <- new_replay_state(checkpoint, resume, B)
  iterations <- state$iterations

  one_draw <- function(i) {
    shuffled <- aligned
    shuffled$effect_y <- aligned$effect_y[perms[[i]]]
    shuffled$fdr_y <- aligned$fdr_y[perms[[i]]]
    res <- apply_selection(spec, shuffled)
    data.frame(iteration = i, converged = TRUE, r = res$r,
               eligible = res$eligible, selected = res$selected,
               common = res$common, error = NA_character_,
               stringsAsFactors = FALSE)
  }

  todo <- setdiff(seq_len(B), iterations$iteration)
  if (length(todo)) {
    chunks <- split(todo, ceiling(seq_along(todo) / max(1L, checkpoint_every)))
    for (chunk in chunks) {
      rows <- if (parallel && requireNamespace("future.apply", quietly = TRUE)) {
        future.apply::future_lapply(chunk, one_draw, future.seed = TRUE)
      } else {
        lapply(chunk, one_draw)
      }
      iterations <- rbind(iterations, do.call(rbind, rows))
      iterations <- iterations[order(iterations$iteration), , drop = FALSE]
      write_checkpoint(checkpoint, iterations, list(seed = seed, B = B))
      if (verbose) message(sprintf("  gene-label replay %d/%d draws complete",
                                   max(iterations$iteration), B))
    }
  }
  list(iterations = iterations, perms = perms, seed = seed, B = B)
}

#' Fixed-set diagnostic comparator
#'
#' Samples gene subsets of the observed size without replacement from the
#' paired-effect universe and recomputes the correlation. This comparator does
#' not regenerate selection and is therefore a **diagnostic** contrast, not the
#' primary valid reference for a post-selection statistic. The result is
#' flagged \code{diagnostic_only = TRUE}.
#'
#' @inheritParams replay_anchored
#' @param replayed_tbl Data frame for the replayed arm (effects only).
#' @param set_size Size of the sampled subsets; defaults to the observed
#'   selected-set size.
#' @return A list with \code{iterations} and \code{diagnostic_only = TRUE}.
#' @keywords internal
replay_fixed_set <- function(fixed_tbl, replayed_tbl, spec, B, set_size = NULL,
                             seed = 1L, checkpoint = NULL, checkpoint_every = 50L,
                             resume = FALSE, parallel = FALSE, verbose = TRUE) {
  aligned <- pair_arms(fixed_tbl, replayed_tbl)
  aligned <- aligned[is.finite(aligned$effect_x) & is.finite(aligned$effect_y) &
                       !aligned$gene %in% spec$exclude, , drop = FALSE]
  n <- nrow(aligned)
  if (is.null(set_size)) {
    set_size <- apply_selection(spec, aligned)$selected
  }
  if (!is.finite(set_size) || set_size < spec$min_selected) {
    stop("Diagnostic comparator requires a defined observed selected set.", call. = FALSE)
  }
  set.seed(seed)
  perms <- replicate(B, sample.int(n, set_size), simplify = FALSE)
  state <- new_replay_state(checkpoint, resume, B)
  iterations <- state$iterations

  one_draw <- function(i) {
    idx <- perms[[i]]
    data.frame(iteration = i, converged = TRUE,
               r = safe_cor(aligned$effect_x[idx], aligned$effect_y[idx], spec$min_selected),
               eligible = set_size, selected = set_size, common = n,
               error = NA_character_, stringsAsFactors = FALSE)
  }
  todo <- setdiff(seq_len(B), iterations$iteration)
  if (length(todo)) {
    chunks <- split(todo, ceiling(seq_along(todo) / max(1L, checkpoint_every)))
    for (chunk in chunks) {
      rows <- if (parallel && requireNamespace("future.apply", quietly = TRUE)) {
        future.apply::future_lapply(chunk, one_draw, future.seed = TRUE)
      } else {
        lapply(chunk, one_draw)
      }
      iterations <- rbind(iterations, do.call(rbind, rows))
      iterations <- iterations[order(iterations$iteration), , drop = FALSE]
      write_checkpoint(checkpoint, iterations, list(seed = seed, B = B))
    }
  }
  list(iterations = iterations, perms = perms, seed = seed, B = B,
       diagnostic_only = TRUE)
}

## Pair two arm tables on gene, keeping the anchored arm's columns as *_x.
pair_arms <- function(fixed_tbl, replayed_tbl) {
  x <- data.frame(gene = fixed_tbl$gene, effect_x = fixed_tbl$effect,
                  fdr_x = fixed_tbl$fdr %||% NA_real_,
                  hub_x = fixed_tbl$hub %||% FALSE, stringsAsFactors = FALSE)
  y <- data.frame(gene = replayed_tbl$gene, effect_y = replayed_tbl$effect,
                  fdr_y = replayed_tbl$fdr %||% NA_real_,
                  hub_y = replayed_tbl$hub %||% FALSE, stringsAsFactors = FALSE)
  merge(x, y, by = "gene", all = FALSE, sort = FALSE)
}

## Summarise a replay result relative to the observed statistic.
summarise_reference <- function(iterations, observed_r) {
  valid <- iterations$converged & is.finite(iterations$r)
  ref <- iterations$r[valid]
  p_info <- add_one_upper_p(observed_r, ref)
  q <- if (length(ref)) stats::quantile(ref, c(0.025, 0.5, 0.95, 0.975), na.rm = TRUE) else
    stats::setNames(rep(NA_real_, 4L), c("2.5%", "50%", "95%", "97.5%"))
  list(
    n_valid = length(ref),
    n_failed = sum(!valid),
    null_mean = if (length(ref)) mean(ref) else NA_real_,
    null_sd = if (length(ref)) stats::sd(ref) else NA_real_,
    null_median = unname(q["50%"]),
    null_q025 = unname(q["2.5%"]),
    null_q95 = unname(q["95%"]),
    null_q975 = unname(q["97.5%"]),
    critical_value = unname(q["95%"]),
    p_value = p_info$p, n_upper = p_info$n_upper, mcse = p_info$mcse,
    percentile = percentile_of(observed_r, ref),
    z_position = if (length(ref) > 1L) (observed_r - mean(ref)) / stats::sd(ref) else NA_real_
  )
}
