#' Summarise a selcorr fit
#'
#' Reports the observed selected correlation, the construction-aware reference,
#' the position of the observed value within it, and the boundary of the
#' statement. The interpretation line states only whether excess alignment
#' relative to the specified reference was detected; it does not translate the
#' result into biological prose.
#'
#' @param object A \code{selcorr} object.
#' @param ... Ignored.
#' @return The object, invisibly.
#' @export
summary.selcorr <- function(object, ...) {
  detected <- is.finite(object$p_value) && object$p_value < 0.05
  cat("Observed selected correlation:", formatC(object$observed_r, digits = 4, format = "f"), "\n")
  cat("Selected genes:", object$n_selected, "of", object$n_eligible, "eligible",
      sprintf("(fraction %.3f)", object$selected_fraction), "\n")
  if (object$diagnostic_only) {
    cat("Reference type: fixed-set diagnostic comparator (selection NOT regenerated)\n")
  } else {
    cat("Reference type:", object$method, "reference (selection regenerated)\n")
  }
  cat("\nConstruction-aware reference\n")
  cat("  Mean:                 ", formatC(object$null_mean, digits = 4, format = "f"), "\n", sep = "")
  cat("  SD:                   ", formatC(object$null_sd, digits = 4, format = "f"), "\n", sep = "")
  cat("  95% critical value:   ", formatC(object$critical_value, digits = 4, format = "f"), "\n", sep = "")
  cat("  Observed percentile:  ", formatC(object$observed_percentile, digits = 1, format = "f"), "\n", sep = "")
  cat("  Upper-tail P:         ", formatC(object$p_value, digits = 4, format = "f"), "\n", sep = "")
  cat("  z position:           ", formatC(object$z_position, digits = 3, format = "f"), "\n", sep = "")
  cat("  Valid draws:          ", object$n_reference_valid, " (failed ", object$n_reference_failed, ")\n", sep = "")
  cat("\nInterpretation\n")
  cat("  Excess alignment relative to this workflow-specific reference: ",
      if (detected) "detected" else "not detected", "\n", sep = "")
  cat("\nBoundary\n")
  cat("  This result concerns the selected-correlation endpoint under the specified\n")
  cat("  workflow. It does not establish absence of other forms of biological sharing.\n")
  invisible(object)
}

#' @export
print.summary.selcorr <- function(x, ...) invisible(x)
