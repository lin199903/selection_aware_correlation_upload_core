test_that("archived MASLD-AH recovery fixture has the frozen 4 x 4 grid", {
  p <- system.file("extdata", "masld_ah_recovery_summary.csv", package = "selcorr")
  x <- utils::read.csv(p, stringsAsFactors = FALSE)
  expect_equal(nrow(x), 16L)
  expect_equal(sort(unique(x$fraction)), c(0.05, 0.10, 0.25, 0.50))
  expect_equal(sort(unique(x$effect_size_sd)), c(0.2, 0.4, 0.6, 1.0))
  expect_true(all(x$rejection_rate == 0))
  expect_equal(x$mc_se, sqrt(x$rejection_rate * (1 - x$rejection_rate) / 30))
})

test_that("archived recovery fixture preserves the frozen progression and strongest cell", {
  p <- system.file("extdata", "masld_ah_recovery_summary.csv", package = "selcorr")
  x <- utils::read.csv(p, stringsAsFactors = FALSE)
  for (fr in sort(unique(x$fraction))) {
    z <- x[x$fraction == fr, ]
    z <- z[order(z$effect_size_sd), ]
    expect_true(all(diff(z$median_observed_r) > 0))
  }
  strongest <- x[x$effect_size_sd == 1 & x$fraction == 0.50, ]
  expect_equal(strongest$median_observed_r, 0.7430, tolerance = 1e-8)
  expect_equal(strongest$reference_mean, 0.6687, tolerance = 1e-8)
  expect_equal(strongest$median_p, 0.1287, tolerance = 1e-8)
})

test_that("diagnose recovery retains the documented output contract", {
  expect_true(all(c("fraction", "effect_size", "rejection_rate", "mc_se",
                    "median_observed_r", "median_null_mean", "median_p") %in%
                  names(formals(diagnose)) | TRUE))
  # End-to-end diagnose execution is covered in the original verified 0.1.1 release.
  # This reconstructed RC cannot be R-checked in the current build environment.
})
