test_that("a run resumes from its checkpoint instead of restarting", {
  set.seed(8)
  genes <- sprintf("G%03d", 1:150)
  x <- data.frame(gene = genes, effect = rnorm(150), fdr = runif(150, 0, 0.3))
  y <- data.frame(gene = genes, effect = rnorm(150), fdr = runif(150, 0, 0.3))
  ckpt <- tempfile(fileext = ".rds")

  ## First pass: only the first 10 draws.
  f1 <- selcorr(x, y, selection = selection_spec("de_anchor"), method = "gene_label",
                B = 10, seed = 17, checkpoint = ckpt, checkpoint_every = 10,
                verbose = FALSE)
  expect_true(file.exists(ckpt))
  state <- readRDS(ckpt)
  expect_equal(nrow(state$iterations), 10L)

  ## Second pass: extend to 20 draws, resuming from the checkpoint.
  f2 <- selcorr(x, y, selection = selection_spec("de_anchor"), method = "gene_label",
                B = 20, seed = 17, checkpoint = ckpt, checkpoint_every = 10,
                resume = TRUE, verbose = FALSE)
  expect_equal(nrow(f2$replay_statistics), 20L)

  ## The first ten draws must be carried over unchanged.
  expect_identical(f2$replay_statistics$r[1:10], f1$replay_statistics$r)

  ## And the full run must match a single uninterrupted run with the same seed.
  f3 <- selcorr(x, y, selection = selection_spec("de_anchor"), method = "gene_label",
                B = 20, seed = 17, verbose = FALSE)
  expect_identical(f2$replay_statistics$r, f3$replay_statistics$r)
  unlink(ckpt)
})

test_that("checkpoints record iteration, statistic and validity columns", {
  set.seed(9)
  genes <- sprintf("G%03d", 1:120)
  x <- data.frame(gene = genes, effect = rnorm(120), fdr = runif(120, 0, 0.3))
  y <- data.frame(gene = genes, effect = rnorm(120), fdr = runif(120, 0, 0.3))
  ckpt <- tempfile(fileext = ".rds")
  selcorr(x, y, selection = selection_spec("de_anchor"), method = "gene_label",
          B = 8, seed = 21, checkpoint = ckpt, checkpoint_every = 4, verbose = FALSE)
  state <- readRDS(ckpt)
  expect_true(all(c("iteration", "converged", "r", "eligible", "selected") %in%
                    names(state$iterations)))
  expect_false(is.null(state$meta$seed))
  unlink(ckpt)
})

test_that("recovery diagnostic returns the documented grid columns", {
  set.seed(12)
  genes <- sprintf("G%03d", 1:120)
  group <- factor(c(rep("case", 5), rep("control", 5)), levels = c("control", "case"))
  expr <- matrix(rnorm(120 * 10), nrow = 120, dimnames = list(genes, NULL))
  x <- data.frame(gene = genes, effect = c(rnorm(40, 1), rnorm(80, 0.05)),
                  fdr = c(runif(40, 0, 0.01), runif(80, 0, 0.6)))
  fit <- selcorr(x, list(expr = expr, group = group), selection = selection_spec("de_anchor"),
                 method = "replay", B = 5, seed = 2, verbose = FALSE)
  rec <- diagnose(fit, type = "recovery", fractions = c(0.25, 0.5),
                  effect_sizes = c(0.5), n_outer = 3, n_perm = 10, seed = 1,
                  verbose = FALSE)
  expect_s3_class(rec, "data.frame")
  expect_true(all(c("fraction", "effect_size", "rejection_rate", "mc_se",
                    "median_observed_r", "median_null_mean", "median_p") %in% names(rec)))
  expect_equal(nrow(rec), 2L)
  expect_true(all(rec$rejection_rate >= 0 & rec$rejection_rate <= 1))
})

test_that("validate() reports portability fields and never merges p values", {
  set.seed(13)
  genes <- sprintf("G%03d", 1:150)
  x <- data.frame(gene = genes, effect = c(rnorm(50, 1), rnorm(100, 0.05)),
                  fdr = c(runif(50, 0, 0.01), runif(100, 0, 0.6)))
  y <- data.frame(gene = genes, effect = rnorm(150), fdr = runif(150, 0, 0.4))
  fit <- selcorr(x, y, selection = selection_spec("de_anchor"), method = "gene_label",
                 B = 10, seed = 3, verbose = FALSE)
  x_new <- data.frame(gene = genes, effect = rnorm(150))
  y_new <- data.frame(gene = genes, effect = rnorm(150))
  v <- validate(fit, x_new, y_new, n_perm = 30, seed = 4, verbose = FALSE)
  expect_true(all(c("n_eval_common", "n_eval_selected", "evaluation_r", "null_mean",
                    "null_sd", "critical_value", "percentile", "p_value") %in% names(v)))
  expect_false("replay_p_value" %in% names(v))
  expect_match(attr(v, "note"), "not combined")
})
