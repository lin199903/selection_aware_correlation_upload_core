## Analytic geometry of agreement-conditioned selection. These functions
## reproduce the population results derived in the analysed manuscript. They are
## provided so that the reference geometry can be checked independently of any
## replay; they introduce no new statistic.

#' Population correlation after same-sign selection
#'
#' For independent standard-normal study statistics, conditioning on a common
#' sign gives a population correlation of \code{2 / pi}.
#'
#' @return A numeric scalar.
#' @examples
#' same_sign_population_correlation()
#' @export
same_sign_population_correlation <- function() 2 / pi

#' Population correlation after symmetric magnitude selection with same signs
#'
#' With \eqn{a = \Phi^{-1}(1 - q/2)} and \eqn{\lambda(a) = \phi(a)/[1-\Phi(a)]},
#' the population correlation among genes retained by both studies under
#' magnitude selection \eqn{q} and sign concordance is
#' \eqn{\lambda(a)^2 / (1 + a\lambda(a))}. At \eqn{q = 1} this reduces to
#' \code{2 / pi}.
#'
#' @param q Fraction retained by each arm (a single value or a vector).
#' @return A numeric vector of population correlations.
#' @examples
#' analytic_selected_correlation(c(1, 0.5, 0.1))
#' @export
analytic_selected_correlation <- function(q) {
  if (any(!is.finite(q)) || any(q <= 0) || any(q > 1)) {
    stop("`q` must lie in (0, 1].", call. = FALSE)
  }
  a <- stats::qnorm(1 - q / 2)
  lambda <- stats::dnorm(a) / (1 - stats::pnorm(a))
  out <- lambda^2 / (1 + a * lambda)
  out[q == 1] <- 2 / pi
  out
}
