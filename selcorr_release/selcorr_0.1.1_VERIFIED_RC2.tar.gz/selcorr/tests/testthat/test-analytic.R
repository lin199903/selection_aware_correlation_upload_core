test_that("same-sign selection gives 2/pi", {
  expect_equal(same_sign_population_correlation(), 2 / pi, tolerance = 1e-12)
})

test_that("magnitude-selection geometry matches the archived analytic values", {
  q <- c(0.90, 0.75, 0.50, 0.25, 0.10)
  expected <- c(0.6964, 0.7732, 0.8698, 0.9371, 0.9685)
  expect_equal(analytic_selected_correlation(q), expected, tolerance = 5e-4)
})

test_that("q = 1 reduces to the same-sign value", {
  expect_equal(analytic_selected_correlation(1), 2 / pi, tolerance = 1e-12)
})

test_that("selection strength increases the population correlation monotonically", {
  q <- seq(1, 0.05, by = -0.05)
  rho <- analytic_selected_correlation(q)
  expect_true(all(diff(rho) > 0))
})

test_that("invalid q is rejected", {
  expect_error(analytic_selected_correlation(0))
  expect_error(analytic_selected_correlation(1.5))
  expect_error(analytic_selected_correlation(NA_real_))
})
