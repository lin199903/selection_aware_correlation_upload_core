# selcorr

`selcorr` constructs workflow-aware reference distributions for correlations
calculated after agreement-based feature selection.

```r
library(selcorr)

fit <- selcorr(x, y, selection = selection_spec("de_anchor"))
summary(fit)
plot(fit)
```

Two further functions sit deliberately below the core object:

```r
diagnose(fit, type = "recovery")   # detection boundary of the calibrated endpoint
validate(fit, x_new, y_new)        # portability of the selected set in independent data
```

## What the package does and does not claim

A reference produced here is tied to the selection workflow that generated it.
A non-significant result concerns the selected-correlation endpoint under that
workflow; it is not evidence that other forms of biological sharing are absent,
and no reference is claimed to be unbiased or universally valid.

## Interfaces

* **Effect-level** — supply two tables with `gene` and `effect` (plus `fdr` and
  optional `hub`). Use `method = "gene_label"` for a replay of the selection
  steps or `method = "fixed_set"` for the diagnostic comparator, which is
  flagged `diagnostic_only = TRUE` because it does not regenerate selection.
* **Sample-level** — supply `expr`, `group` and optional covariates. Use
  `method = "replay"` for the primary construction-aware reference: a
  Freedman-Lane residual permutation of the replayed arm with model refitting,
  differential-expression filtering, eligibility reconstruction, same-sign
  selection and the selected correlation re-evaluated on every draw.

## Anchoring direction

`anchor = "x"` or `anchor = "y"` selects which arm is held fixed.
`selcorr_bidir()` runs both and returns two separate estimands; the null centre,
dispersion and p value are never averaged.

## Provenance

The package is a refactor of archived, validated analysis scripts; the mapping
is recorded in `inst/provenance/PACKAGE_PROVENANCE_MAP.md`.
