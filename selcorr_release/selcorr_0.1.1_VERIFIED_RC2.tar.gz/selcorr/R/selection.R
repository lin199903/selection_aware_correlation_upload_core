#' Specify the selection rule explicitly
#'
#' The reference produced by \code{\link{selcorr}} is defined by the selection
#' workflow, so the workflow is a required, visible input. This constructor
#' records the eligibility rule, the magnitude rule and the direction rule, and
#' stores them in the fitted object as \code{fit$spec} so that the origin of a
#' reference can always be reconstructed.
#'
#' @param eligibility One of \code{"de_anchor"} or \code{"hub_de"}, or a
#'   function. \code{"de_anchor"} defines the eligible pool as the anchored
#'   arm's differentially expressed genes (the rule used by the archived
#'   same-disease workflow). \code{"hub_de"} defines the pool as
#'   \code{(hub_replayed AND DE_anchored) OR (hub_anchored AND DE_replayed)}
#'   (the rule used by the archived cross-disease workflow). A function is
#'   called with a data frame containing \code{gene}, \code{effect_x},
#'   \code{effect_y}, \code{fdr_x}, \code{fdr_y}, \code{hub_x}, \code{hub_y}
#'   and must return a logical vector.
#' @param fdr_cut FDR threshold for the magnitude rule.
#' @param abs_effect_cut Absolute-effect threshold for the magnitude rule.
#' @param direction Direction rule; \code{"same_sign"} retains genes whose two
#'   effects have the same sign.
#' @param min_selected Minimum number of selected genes required for the
#'   correlation to be defined.
#' @param exclude Genes excluded by convention before analysis (defaults to the
#'   Y-chromosome list used in the archived analyses).
#' @return An object of class \code{selcorr_selection}.
#' @examples
#' selection_spec("de_anchor")
#' selection_spec("hub_de", fdr_cut = 0.05, abs_effect_cut = 0.3)
#' @export
selection_spec <- function(eligibility = c("de_anchor", "hub_de"),
                           fdr_cut = .selcorr_defaults$fdr_cut,
                           abs_effect_cut = .selcorr_defaults$abs_effect_cut,
                           direction = "same_sign",
                           min_selected = .selcorr_defaults$min_selected,
                           exclude = .y_chromosome_genes) {
  if (is.character(eligibility)) {
    eligibility <- match.arg(eligibility)
  } else if (!is.function(eligibility)) {
    stop("`eligibility` must be \"de_anchor\", \"hub_de\" or a function.", call. = FALSE)
  }
  if (!identical(direction, "same_sign")) {
    stop("Only direction = \"same_sign\" is defined in selcorr 0.1.", call. = FALSE)
  }
  spec <- list(
    eligibility = eligibility,
    magnitude_rule = list(fdr_cut = as.numeric(fdr_cut),
                          abs_effect_cut = as.numeric(abs_effect_cut)),
    direction_rule = direction,
    min_selected = as.integer(min_selected),
    exclude = as.character(exclude)
  )
  class(spec) <- "selcorr_selection"
  spec
}

#' @export
print.selcorr_selection <- function(x, ...) {
  cat("<selcorr_selection>\n")
  cat("  eligibility      : ", if (is.function(x$eligibility)) "<function>" else x$eligibility, "\n", sep = "")
  cat("  magnitude rule   : FDR < ", x$magnitude_rule$fdr_cut,
      " and |effect| > ", x$magnitude_rule$abs_effect_cut, "\n", sep = "")
  cat("  direction rule   : ", x$direction_rule, "\n", sep = "")
  cat("  min selected     : ", x$min_selected, "\n", sep = "")
  cat("  excluded genes   : ", length(x$exclude), " (Y chromosome by default)\n", sep = "")
  invisible(x)
}

## Internal: apply the selection rule to a paired gene table.
## `tbl` has columns gene, effect_x, fdr_x, effect_y, fdr_y and optionally
## hub_x, hub_y.
apply_selection <- function(spec, tbl) {
  fdr_cut <- spec$magnitude_rule$fdr_cut
  lfc_cut <- spec$magnitude_rule$abs_effect_cut

  tbl <- tbl[is.finite(tbl$effect_x) & is.finite(tbl$effect_y) &
               !tbl$gene %in% spec$exclude, , drop = FALSE]
  if (!nrow(tbl)) {
    return(list(common = 0L, eligible = 0L, selected = 0L, r = NA_real_,
                selected_genes = character(0), pool_genes = character(0)))
  }
  sig_x <- is.finite(tbl$fdr_x) & tbl$fdr_x < fdr_cut & abs(tbl$effect_x) > lfc_cut
  sig_y <- is.finite(tbl$fdr_y) & tbl$fdr_y < fdr_cut & abs(tbl$effect_y) > lfc_cut

  elig <- if (is.function(spec$eligibility)) {
    as.logical(spec$eligibility(tbl))
  } else if (identical(spec$eligibility, "de_anchor")) {
    sig_x
  } else {
    if (is.null(tbl$hub_x) || is.null(tbl$hub_y)) {
      stop("eligibility = \"hub_de\" requires `hub_x` and `hub_y` in both arms.",
           call. = FALSE)
    }
    (tbl$hub_y & sig_x) | (tbl$hub_x & sig_y)
  }
  elig[is.na(elig)] <- FALSE
  pool <- tbl[elig, , drop = FALSE]
  same <- pool$effect_x * pool$effect_y > 0
  sel <- pool[same, , drop = FALSE]

  list(
    common = nrow(tbl),
    eligible = nrow(pool),
    selected = nrow(sel),
    r = safe_cor(sel$effect_x, sel$effect_y, spec$min_selected),
    selected_genes = sel$gene,
    pool_genes = pool$gene
  )
}
